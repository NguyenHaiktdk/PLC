﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Windows.Forms;

namespace UI_WinForm_Template.Forms
{
    public partial class FormMenuPrincipal : Form
    {
        public static FormMenuPrincipal Instance;
        private int tolerance = 15;
        private const int WM_NCHITTEST = 132;
        private const int HTBOTTOMRIGHT = 17;
        private Rectangle sizeGripRectangle;

        #region--Lay duong dan hien tai Application---
        static public string SettingFilePath = Application.StartupPath + "\\Config";
        #endregion

        public FormMenuPrincipal()
        {
            InitializeComponent();
            this.SetStyle(ControlStyles.ResizeRedraw, true);
            this.DoubleBuffered = true;
            this.Opacity = 0.96;
            this.panelBackgroundForm.BackColor = Color.FromArgb(64, 69, 76);
            UserControls.UC_MachineLayout uch = new UserControls.UC_MachineLayout();
            AddControlsToPanel(uch);
            //MessageBox.Show(SettingFilePath);
        }

     

        private void AddControlsToPanel(Control c)
        {
            c.Dock = DockStyle.Fill;
            panelContainerForm.Controls.Clear();
            panelContainerForm.Controls.Add(c);
        }
       
        protected override void WndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case WM_NCHITTEST:
                    base.WndProc(ref m);
                    var hitPoint = this.PointToClient(new Point(m.LParam.ToInt32() & 0xffff, m.LParam.ToInt32() >> 16));
                    if (sizeGripRectangle.Contains(hitPoint))
                        m.Result = new IntPtr(HTBOTTOMRIGHT);
                    break;
                default:
                    base.WndProc(ref m);
                    break;
            }
        }
        
        protected override void OnSizeChanged(EventArgs e)
        {
            base.OnSizeChanged(e);
            var region = new Region(new Rectangle(0, 0, this.ClientRectangle.Width, this.ClientRectangle.Height));

            sizeGripRectangle = new Rectangle(this.ClientRectangle.Width - tolerance, this.ClientRectangle.Height - tolerance, tolerance, tolerance);

            region.Exclude(sizeGripRectangle);
            this.panelBackgroundForm.Region = region;
            this.Invalidate();
        }
 
        protected override void OnPaint(PaintEventArgs e)
        {

            SolidBrush blueBrush = new SolidBrush(Color.FromArgb(55, 61, 69));
            e.Graphics.FillRectangle(blueBrush, sizeGripRectangle);

            base.OnPaint(e);
            ControlPaint.DrawSizeGrip(e.Graphics, Color.Transparent, sizeGripRectangle);
        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);

        private void tmExpandMenu_Tick(object sender, EventArgs e)
        {
            if (panelMenu.Width >= 230)
                this.tmExpandMenu.Stop();
            else
                panelMenu.Width = panelMenu.Width + 5;
        }

        private void tmCollapseMenu_Tick(object sender, EventArgs e)
        {

            if (panelMenu.Width <= 55)
                this.tmCollapseMenu.Stop();
            else
                panelMenu.Width = panelMenu.Width - 5;
        }

        private void tmDateTime_Tick(object sender, EventArgs e)
        {
            lbDate.Text = DateTime.Now.ToLongDateString();
            lbTime.Text = DateTime.Now.ToString("HH:mm:ssss");
        }

       

        private void panelTitleBar_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        #region---Close App---
        private void btnCerrar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to exit.", "Message", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void btnShutDown_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        #endregion

        #region ---Zone Control App---
        private void btnMinimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        int lx, ly;
        int sw, sh;

        private void BtnMenu_Click(object sender, EventArgs e)
        {

            if (panelMenu.Width == 230)
            {
                this.tmCollapseMenu.Start();
            }
            else if (panelMenu.Width == 55)
            {
                this.tmExpandMenu.Start();
            }
        }

        private void PanelContainerForm_Paint(object sender, PaintEventArgs e)
        {

        }

        private void BtnUsers_Click(object sender, EventArgs e)
        {
            UserControls.UC_ManageUser uch = new UserControls.UC_ManageUser();
            AddControlsToPanel(uch);
        }

        private void btnNormal_Click(object sender, EventArgs e)
        {
            this.Size = new Size(sw, sh);
            this.Location = new Point(lx, ly);
            btnNormal.Visible = false;
            btnMaximizar.Visible = true;
        }
        private void btnMaximizar_Click(object sender, EventArgs e)
        {
            lx = this.Location.X;
            ly = this.Location.Y;
            sw = this.Size.Width;
            sh = this.Size.Height;
            this.Size = Screen.PrimaryScreen.WorkingArea.Size;
            this.Location = Screen.PrimaryScreen.WorkingArea.Location;
            btnMaximizar.Visible = false;
            btnNormal.Visible = true;
        }
        #endregion

        #region ---Log---
        //public void ClearLogResult()
        //{
        //    if (lbLog.InvokeRequired)
        //    {
        //        lbLog.Invoke(new MethodInvoker(() => { ClearLogResult(); }));
        //    }
        //    else
        //    {
        //        lbLog.Items.Clear();
        //    }
        //}
        //public void DisplayLog(string log)
        //{
        //    if (lbLog.InvokeRequired)
        //    {
        //        lbLog.Invoke(new MethodInvoker(() => { DisplayLog(log); }));
        //    }
        //    else
        //    {
        //        if (lbLog.Items.Count > 100)
        //        {
        //            lbLog.Items.RemoveAt(0);
        //        }
        //        lbLog.Items.Add(log);
        //        lbLog.SelectedIndex = (lbLog.Items.Count - 1);
        //    }
        //}
        #endregion
    }
}
