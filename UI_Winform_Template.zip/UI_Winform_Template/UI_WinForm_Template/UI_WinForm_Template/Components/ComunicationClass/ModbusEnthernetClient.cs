﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace UI_WinForm_Template.Components.ComunicationClass
{
   public class ModbusEnthernetClient
    {


        private const int READ_BUFFER_SIZE = 2048; // .

        private const int WRITE_BUFFER_SIZE = 2048; // .

        private byte[] bufferReceiver = null;
        private byte[] bufferSender = null;

        //private IPEndPoint server = null;

        private Socket mSocket = null;

        private string IP = "127.0.0.1";
        private int Port = 502;
        private int ConntectTimeout = 3000;

        public string stringData = "";

        public ModbusEnthernetClient(string ip = "127.0.0.1", int port = 502)
        {
            this.IP = ip;
            this.Port = port;

        }

        internal void ReceiveData()
        {
            throw new NotImplementedException();
        }

        public ModbusEnthernetClient(string ip, short port, int conntectTimeout)
            : this(ip, port)
        {
            this.SetTimeout(conntectTimeout);
        }

        public void Connect()
        {
            try
            {
                this.mSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                this.bufferReceiver = new byte[READ_BUFFER_SIZE];
                this.bufferSender = new byte[WRITE_BUFFER_SIZE];
                this.mSocket.SendBufferSize = READ_BUFFER_SIZE;
                this.mSocket.ReceiveBufferSize = WRITE_BUFFER_SIZE;
                IPEndPoint server = new IPEndPoint(IPAddress.Parse(this.IP), this.Port);
                this.mSocket.Connect(server);
                ////this.mSocket.NoDelay = false;
                //newsock.BeginConnect(server, new AsyncCallback(Connected), newsock);                
            }
            catch (SocketException ex)
            {
                throw ex;
            }

        }

        public void Close()
        {
            if (this.mSocket == null) return;
            if (this.mSocket.Connected)
            {
                this.mSocket.Close();
            }
        }

        public void SetTimeout(int conntectTimeout)
        {
            this.ConntectTimeout = conntectTimeout;
        }

        public int Write(byte[] frame)
        {
            try
            {
                return this.mSocket.Send(frame, frame.Length, SocketFlags.None);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public byte[] Read()
        {
            try
            {
                NetworkStream ns = new NetworkStream(this.mSocket);

                if (ns.CanRead)
                {
                    int rs = this.mSocket.Receive(this.bufferReceiver, this.bufferReceiver.Length, SocketFlags.None);
                }
                return this.bufferReceiver;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        private Socket client;

        private void Connected(IAsyncResult iar)
        {
            client = (Socket)iar.AsyncState;
            try
            {
                client.EndConnect(iar);
                //conStatus.Text = "Connected to: " + client.RemoteEndPoint.ToString();
                client.BeginReceive(bufferReceiver, 0, READ_BUFFER_SIZE, SocketFlags.None,
                              new AsyncCallback(ReceiveData), client);
            }
            catch (SocketException ex)
            {
                throw ex;
            }
        }

        public void ReceiveData(IAsyncResult iar)
        {
            try
            {
                byte[] data = new byte[1024];
                Socket remote = (Socket)iar.AsyncState;
                int recv = remote.EndReceive(iar);
                stringData = Encoding.ASCII.GetString(data, 0, recv); 
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void SendData(IAsyncResult iar)
        {
            try
            {
                Socket remote = (Socket)iar.AsyncState;
                int sent = remote.EndSend(iar);
                remote.BeginReceive(this.bufferSender, 0, WRITE_BUFFER_SIZE, SocketFlags.None,
                              new AsyncCallback(ReceiveData), remote);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public void SendData(string msg)
        {
            byte[] _data = new byte[1024];
            _data = Encoding.ASCII.GetBytes(msg);
            client.Send(_data, _data.Length, SocketFlags.None);
           
        }

    }
}
