﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace UI_WinForm_Template.Components.ComunicationClass
{
    public class TCPIPClient
    {
        public bool isConect = false;
        public string recv_buf = ""; 
        Socket client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        public bool Connect(string host, int port)
        {
            try
            {
                IPEndPoint iep = new IPEndPoint(IPAddress.Parse(host), port);
                client.Connect(iep);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                client.Close();
                return false;
            }
            return true;
        }
        public string ReceiveData()
        {
            try
            {
                byte[] _data = new byte[1024];
                int recv = client.Receive(_data);
                recv_buf = Encoding.ASCII.GetString(_data, 0, recv);  
            }
            catch (Exception e)
            {
                client.Disconnect(true);
                client.Close();
                return e.ToString().Trim();
            }
            return recv_buf;
        }
        public void SendData(string msg)
        {
            byte[] _data = new byte[1024];
            _data = Encoding.ASCII.GetBytes(msg);
            client.Send(_data, _data.Length, SocketFlags.None);
        }
        public void Close()
        {
            client.Close();
        }
        public void Disconnect(bool state)
        {
            client.Disconnect(true);
        }
    }
}
