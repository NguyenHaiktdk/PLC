﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UI_WinForm_Template.Forms;

namespace UI_WinForm_Template.Components.LogClass
{
    public class LogClass
    {
        static string modelName;
        static public Queue<string> logQueue;
        static public Queue<string> logPmQueue;
        static public Queue<string> logLocation;

        public LogClass(string _modelName)
        {
            modelName = _modelName;
            logQueue = new Queue<string>();
            logPmQueue = new Queue<string>();
            logLocation = new Queue<string>();

        }

        public static void AddLog(string msg)
        {
            string logTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss : ");
            // if( mainForm != null )
            //FormMenuPrincipal.Instance.DisplayLog(logTime + msg);
            if (logQueue != null)
                logQueue.Enqueue(logTime + msg);
        }

        public static void SaveLog()
        {

        }

        public static void AddLocationLog(string msg)
        {
            string logTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss : ");

            if (logLocation != null)
                logLocation.Enqueue(logTime + msg);
        }
    }
}
