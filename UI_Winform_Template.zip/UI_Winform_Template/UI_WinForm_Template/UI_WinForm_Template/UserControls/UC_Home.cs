﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using UI_WinForm_Template.Components;
using SLRDbConnector;

namespace UI_WinForm_Template.UserControls
{
    public partial class UC_Home : UserControl
    {
        private resizeClass HomeResizeClass = null;
        DbConnector db; 
        public UC_Home()
        {
            InitializeComponent();
            db = new DbConnector();
            this.Load += UC_Home_Load; 
        }

        private void UC_Home_Load(object sender, EventArgs e)
        {
            InsertarFilas();
            HomeResizeClass = new resizeClass(this);
            HomeResizeClass._get_initial_size();
            this.Resize += UC_Home_Resize;
        }

        private void UC_Home_Resize(object sender, EventArgs e)
        {
            HomeResizeClass._resize();
        }

        private void InsertarFilas()
        {
            db.fillDataGridView("select * from TestLib", dataGridView1);
        }
    }
}
