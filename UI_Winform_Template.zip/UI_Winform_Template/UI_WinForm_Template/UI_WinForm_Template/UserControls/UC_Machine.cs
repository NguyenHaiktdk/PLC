﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using UI_WinForm_Template.Components;

namespace UI_WinForm_Template.UserControls
{
    public partial class UC_Machine : UserControl
    {

        public string id;
        public UC_Machine()
        {
            InitializeComponent();
        }
        public UC_Machine(string Name,string ID)
        {
            InitializeComponent();
            this.Name = Name;
            this.id = ID;
        }
    }
}
