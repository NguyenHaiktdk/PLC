﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using UI_WinForm_Template.Components.ComunicationClass;
using System.Threading;

namespace UI_WinForm_Template.UserControls
{
    public partial class UC_TestClient : UserControl
    {
        private ModbusEnthernetClient EnthernetClient = null;
        TCPIPClient client = new TCPIPClient();
        string _recv_buf = "";
        public UC_TestClient()
        {
            InitializeComponent();
            EnthernetClient = new ModbusEnthernetClient();
            
        }
        public void ReceiveData()
        {
            try
            {
                while (true)
                {
                    byte[] _recv_buf = EnthernetClient.Read();
                    string data = Encoding.ASCII.GetString(_recv_buf);
                    DoWorkOnUI(data);
                }
            }
            catch (Exception e)
            {
                //MessageBox.Show("Gặp vấn đề về đọc dữ liệu!" + e.Message, "Lỗi");
                client.Close();
            }
        }
        private void DoWorkOnUI(string data)
        {
            MethodInvoker methodInvokerDelegate = delegate ()
            { tbRecvdata.Text = data; };

            //This will be true if Current thread is not UI thread.
            if (this.InvokeRequired)
                this.Invoke(methodInvokerDelegate);
            else
                methodInvokerDelegate();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            //string a = tbHost.Text;
            //int b = int.Parse(tbPort.Text);
            try
            {
                EnthernetClient.Connect();
                Thread listen = new Thread(ReceiveData);
                listen.IsBackground = true;
                listen.Start();
               
            }
            catch (Exception)
            {

                MessageBox.Show("Khong the ket noi toi server");
            }
           
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            client.SendData(tbData.Text.ToString());
        }
    }
}
