﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using UI_WinForm_Template.Components;

namespace UI_WinForm_Template.UserControls
{
   
    public partial class UC_Logo : UserControl
    {
        public UC_Logo()
        {
            InitializeComponent();
        }
    }
}
