﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using UI_WinForm_Template.Components;

namespace UI_WinForm_Template.UserControls
{
    public partial class UC_MachineLayout : UserControl
    {
        List<UC_Machine> _listA;
        private resizeClass MachineLayoutResizeClass = null;
        public UC_MachineLayout()
        {
            InitializeComponent();

            _listA = new List<UC_Machine>();

            this.Load += UC_MachineLayout_Load;
            UserControls.UC_Machine a = new UserControls.UC_Machine("A","192.168.0.1");
            UserControls.UC_Machine b = new UserControls.UC_Machine("B", "192.168.0.2");
            UserControls.UC_Machine c = new UserControls.UC_Machine("C", "192.168.0.3");
            UserControls.UC_Machine d = new UserControls.UC_Machine("D", "192.168.0.4");
            UserControls.UC_Machine e = new UserControls.UC_Machine("E", "192.168.0.5");
            UserControls.UC_Machine f = new UserControls.UC_Machine("F", "192.168.0.6");
            a.DoubleClick += A_DoubleClick;
            b.DoubleClick += A_DoubleClick;
            c.DoubleClick += A_DoubleClick;
            d.DoubleClick += A_DoubleClick;
            e.DoubleClick += A_DoubleClick;
            f.DoubleClick += A_DoubleClick;
            _listA.Add(a);
            _listA.Add(b);

            flowLayoutPanel1.Controls.Add(a);
            flowLayoutPanel1.Controls.Add(b);
            flowLayoutPanel1.Controls.Add(c);
            flowLayoutPanel1.Controls.Add(d);
            flowLayoutPanel1.Controls.Add(e);
            flowLayoutPanel1.Controls.Add(f);
            ControlExtension.Draggable(a, true);
            ControlExtension.Draggable(b, true);
            ControlExtension.Draggable(c, true);
            ControlExtension.Draggable(d, true);
            ControlExtension.Draggable(e, true);
            ControlExtension.Draggable(f, true);
        }

        private void A_DoubleClick(object sender, EventArgs e)
        {
            UC_Machine a = sender as UC_Machine;
            string h = a.Name;
            string id = a.id;
            MessageBox.Show(h + id);
        }

        private void UC_MachineLayout_Load(object sender, EventArgs e)
        {
            MachineLayoutResizeClass = new resizeClass(this);
            MachineLayoutResizeClass._get_initial_size();
            this.Resize += UC_MachineLayout_Resize;
        }
        private void UC_MachineLayout_Resize(object sender, EventArgs e)
        {
            MachineLayoutResizeClass._resize();
        }
    }
}
